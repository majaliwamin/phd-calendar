"""HTTP layer for governance. Role + department scope are enforced here on the server for every route."""
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import Response
import comms, db, governance as g
from comms_api import who

router = APIRouter(prefix="/api/gov")

def _run(fn):
    try: return fn()
    except PermissionError as e: raise HTTPException(403, str(e))
    except ValueError as e: raise HTTPException(400, str(e))

def staff(req, perm="gov_view", any_of=()):
    """Authenticate and check permission; returns (staff, scope). HOD scope = own department's modules."""
    try: s = who(req, perm)
    except HTTPException as e:
        if e.status_code != 403 or not any_of: raise
        for p in any_of:
            try: s = who(req, p); break
            except HTTPException: s = None
        if not s: raise
    with db.conn() as c: return dict(s), g.scope(c, s)

async def body(req):
    try: return await req.json()
    except Exception: return {}

@router.get("/overview")
def overview(req: Request, date_from: str = "", date_to: str = ""):
    s, sc = staff(req)
    with db.conn() as c: return g.overview(c, sc, date_from=date_from or None, date_to=date_to or None)

@router.get("/ops")
def ops(req: Request):
    s, sc = staff(req, "gov_view")
    if s["role"] not in ("admin", "coordinator", "hod"): raise HTTPException(403, "The operational dashboard is for the Coordinator (and HOD within their department).")
    with db.conn() as c: return g.ops(c, sc)

@router.get("/modules")
def modules(req: Request, status: str = "", dept_id: int = 0):
    s, sc = staff(req)
    with db.conn() as c: return [m for m in g.all_facts(c, sc) if (not status or m["status"] == status) and (not dept_id or m["dept_id"] == dept_id)]

@router.get("/drill")
def drill(req: Request, dept: str = None, module: str = None, session: str = None, intervention: str = None):
    s, sc = staff(req)
    with db.conn() as c: return _run(lambda: g.drill(c, sc, dept, module, session, intervention))

@router.post("/modules/{mid}/config")
async def module_config(mid: int, req: Request):
    s, sc = staff(req, "gov_ops", ("*",)); b = await body(req)
    with db.conn() as c:
        ch = {k: b.get(k) or None for k in ("dept_id", "planned_start", "planned_end") if k in b}
        _run(lambda: db.update(c, s["name"], "modules", mid, ch)); g.recompute(c, mid, s["name"], "auto")
    return {"ok": True}

@router.post("/modules/{mid}/complete")
async def complete(mid: int, req: Request):
    s, sc = staff(req, "gov_complete"); b = await body(req)
    if not g.in_scope(sc, mid): raise HTTPException(403, "Module is outside your department.")
    with db.conn() as c: _run(lambda: g.mark_complete(c, s, mid, b.get("reason", ""), bool(b.get("override"))))
    return {"ok": True}

@router.post("/modules/{mid}/reopen")
async def reopen(mid: int, req: Request):
    s, sc = staff(req, "gov_complete"); b = await body(req)
    if not g.in_scope(sc, mid): raise HTTPException(403, "Module is outside your department.")
    with db.conn() as c: _run(lambda: g.reopen_module(c, s, mid, b.get("reason", "")))
    return {"ok": True}

@router.get("/modules/{mid}/history")
def mhistory(mid: int, req: Request):
    s, sc = staff(req)
    if not g.in_scope(sc, mid): raise HTTPException(403, "Module is outside your scope.")
    with db.conn() as c: return g.module_history(c, mid)

@router.post("/delivery")
async def delivery(req: Request):
    s, sc = staff(req, "gov_record"); b = await body(req)
    with db.conn() as c: _run(lambda: g.record_delivery(c, s, int(b["session_id"]), b["state"], b.get("actual_start") or None, b.get("actual_end") or None, b.get("note", ""), None, sc))
    return {"ok": True}

@router.post("/reports/{rid}/verify")
async def verify(rid: int, req: Request):
    s, sc = staff(req, "gov_record"); b = await body(req)
    with db.conn() as c: _run(lambda: g.verify_report(c, s, rid, b["outcome"], b.get("note", ""), b.get("apply", True), sc))
    return {"ok": True}

@router.get("/interventions")
def interventions(req: Request, status: str = "", module_id: int = 0, dept_id: int = 0, severity: str = "", facilitator_id: int = 0, responsible_id: int = 0, date_from: str = "", date_to: str = "", overdue: bool = False):
    s, sc = staff(req)
    with db.conn() as c:
        f = {k: v for k, v in dict(status=status, module_id=module_id, dept_id=dept_id, severity=severity, facilitator_id=facilitator_id, responsible_id=responsible_id, date_from=date_from, date_to=date_to, overdue=overdue).items() if v}
        return g.list_interventions(c, sc, **f)

@router.post("/interventions")
async def create(req: Request):
    s, sc = staff(req, "gov_act"); b = await body(req)
    if s["role"] == "dean": raise HTTPException(403, "Interventions are raised by the Coordinator/HOD; the Dean may escalate.")
    with db.conn() as c: return {"id": _run(lambda: g.create_intervention(c, s, b, sc))}

@router.get("/interventions/{iid}")
def idetail(iid: int, req: Request):
    s, sc = staff(req)
    with db.conn() as c: return _run(lambda: g.detail(c, iid, sc))

@router.post("/interventions/{iid}/{op}")
async def iop(iid: int, op: str, req: Request):
    s, sc = staff(req, "gov_act"); b = await body(req)
    if s["role"] == "dean" and op not in ("transition",): raise HTTPException(403, "The Executive Dean may escalate, return or reopen; other steps are operational.")
    with db.conn() as c:
        if op == "transition": _run(lambda: g.transition(c, s, iid, b["to"], b.get("note", ""), sc))
        elif op == "assign": _run(lambda: g.assign(c, s, iid, b.get("staff_id") or None, b.get("office", ""), b.get("target_date"), sc))
        elif op == "actions": _run(lambda: g.add_action(c, s, iid, b["category"], b.get("note", ""), b.get("due") or None, sc))
        elif op == "replacement": return {"session_id": _run(lambda: g.link_replacement(c, s, iid, b.get("date"), b.get("start"), b.get("end"), sc))}
        elif op == "close": _run(lambda: g.close(c, s, iid, b.get("note", ""), bool(b.get("waive")), sc))
        else: raise HTTPException(404)
    return {"ok": True}

@router.post("/actions/{aid}/complete")
async def action_done(aid: int, req: Request):
    s, sc = staff(req, "gov_act"); b = await body(req)
    with db.conn() as c: _run(lambda: g.complete_action(c, s, aid, b.get("outcome", ""), sc))
    return {"ok": True}

@router.get("/staff")
def staff_list(req: Request):
    staff(req, "gov_act")
    with db.conn() as c: return comms.rows(c, "select id,name,role,dept_id from staff where active=1 order by name")

@router.get("/departments")
def departments(req: Request):
    staff(req)
    with db.conn() as c: return comms.rows(c, "select * from departments order by name")

@router.post("/departments")
async def add_department(req: Request):
    s, sc = staff(req, "*"); b = await body(req)
    with db.conn() as c:
        if not (b.get("name") or "").strip(): raise HTTPException(400, "Name required")
        c.execute("insert or ignore into departments(name) values(?)", (b["name"].strip(),)); comms.audit(c, s["name"], "department_add", b["name"])
    return {"ok": True}

@router.get("/categories")
def categories(req: Request):
    staff(req)
    with db.conn() as c: return comms.rows(c, "select * from action_categories where active=1 order by id")

@router.post("/categories")
async def add_category(req: Request):
    s, sc = staff(req, "*"); b = await body(req)
    with db.conn() as c: c.execute("insert or ignore into action_categories(name) values(?)", ((b.get("name") or "").strip(),)); comms.audit(c, s["name"], "category_add", b.get("name"))
    return {"ok": True}

@router.get("/notices")
def notices(req: Request):
    s, sc = staff(req)
    with db.conn() as c: return comms.rows(c, "select ts,text from inapp where ref=? order by id desc limit 30", f"staff:{s['id']}")

@router.get("/export/{what}.csv")
def export_csv(what: str, req: Request):
    s, sc = staff(req)
    if what not in ("interventions", "modules"): raise HTTPException(404)
    with db.conn() as c: data = g.export_csv(c, sc, what)
    return Response(data, media_type="text/csv", headers={"Content-Disposition": f"attachment; filename={what}.csv"})

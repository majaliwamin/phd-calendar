"""Academic governance: verified delivery records, module status engine, intervention register, dashboards.
One source of truth: every dashboard/metric is computed from `sessions()` + the same tables. Stdlib only."""
import csv, io, datetime as dt, hashlib
import comms, db

TABLES = ("departments", "deliveries", "delivery_log", "module_status", "status_history", "completions", "interventions", "intervention_actions", "intervention_log", "action_categories", "gov_notified")
OK = ("delivered", "late")
STATUSES = ("not_commenced", "in_progress", "completed", "delayed", "under_review")
SCHEMA = """
CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS deliveries(session_id INTEGER PRIMARY KEY, state TEXT, actual_start TEXT, actual_end TEXT, minutes_late INTEGER, verified INTEGER, recorded_by TEXT, verified_by TEXT, ts TEXT, source TEXT, note TEXT, report_id INTEGER);
CREATE TABLE IF NOT EXISTS delivery_log(id INTEGER PRIMARY KEY, session_id INTEGER, ts TEXT, actor TEXT, old_state TEXT, new_state TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS module_status(module_id INTEGER PRIMARY KEY, status TEXT, since TEXT);
CREATE TABLE IF NOT EXISTS status_history(id INTEGER PRIMARY KEY, module_id INTEGER, ts TEXT, old TEXT, new TEXT, actor TEXT, kind TEXT, reason TEXT, evidence TEXT, reviewer TEXT);
CREATE TABLE IF NOT EXISTS completions(module_id INTEGER PRIMARY KEY, by TEXT, ts TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS interventions(id INTEGER PRIMARY KEY, ref TEXT UNIQUE, raised_ts TEXT, source TEXT, module_id INTEGER, session_id INTEGER, dept_id INTEGER, facilitator_id INTEGER, nature TEXT, description TEXT,
  report_id INTEGER, severity TEXT DEFAULT 'medium', state TEXT, action_taken TEXT, responsible_staff_id INTEGER, responsible_office TEXT, target_date TEXT, notes TEXT, evidence TEXT,
  resolved_ts TEXT, confirmed_by TEXT, replacement_session_id INTEGER, closed_ts TEXT, raised_by TEXT);
CREATE TABLE IF NOT EXISTS intervention_actions(id INTEGER PRIMARY KEY, intervention_id INTEGER, ts TEXT, actor TEXT, category TEXT, note TEXT, due TEXT, done INTEGER DEFAULT 0, outcome TEXT, done_ts TEXT);
CREATE TABLE IF NOT EXISTS intervention_log(id INTEGER PRIMARY KEY, intervention_id INTEGER, ts TEXT, actor TEXT, from_state TEXT, to_state TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS action_categories(id INTEGER PRIMARY KEY, name TEXT UNIQUE, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS gov_notified(key TEXT PRIMARY KEY, ts TEXT);
"""
IMMUTABLE = ("delivery_log", "status_history", "intervention_log")
CATEGORIES = ("Contacted the facilitator", "Requested an explanation", "Arranged a replacement session", "Referred the matter to the HOD", "Referred the matter to the Executive Dean",
              "Requested a revised module delivery plan", "Scheduled a follow-up review", "Confirmed the missed session was delivered later")
FLOW = {"reported": ("acknowledged", "escalated"), "acknowledged": ("under_assessment", "escalated"), "under_assessment": ("action_assigned", "escalated"),
        "action_assigned": ("follow_up", "escalated"), "follow_up": ("resolved", "escalated", "action_assigned"), "resolved": ("returned",), "returned": ("follow_up", "escalated"),
        "escalated": ("under_assessment", "action_assigned", "follow_up", "resolved"), "closed": ("reopened",), "reopened": ("under_assessment",)}
INVESTIGATING = ("reported", "acknowledged", "under_assessment", "returned", "escalated", "reopened")
OPEN = ("reported", "acknowledged", "under_assessment", "action_assigned", "follow_up", "returned", "escalated", "reopened")

def triggers(c):
    for t in IMMUTABLE:
        for op in ("UPDATE", "DELETE"):
            c.execute(f"CREATE TRIGGER IF NOT EXISTS {t}_no_{op.lower()} BEFORE {op} ON {t} BEGIN SELECT RAISE(ABORT, '{t} is an immutable audit table'); END")
def suspend_triggers(c):
    for t in IMMUTABLE:
        for op in ("update", "delete"): c.execute(f"DROP TRIGGER IF EXISTS {t}_no_{op}")
def init(c):
    c.executescript(SCHEMA); triggers(c)
    if not c.execute("select count(*) from action_categories").fetchone()[0]:
        c.executemany("insert into action_categories(name) values(?)", [(x,) for x in CATEGORIES])

def today(): return comms.now().date().isoformat()
def ts(): return comms.iso(comms.now())
def rows(c, sql, *a): return comms.rows(c, sql, *a)
def one(c, sql, *a): return comms.one(c, sql, *a)

# ---------- scope (backend-enforced) ----------
def scope(c, s):
    """None = everything. HOD = modules of own department. Everyone else without gov permission = nothing."""
    if s["role"] in ("admin", "coordinator", "dean"): return None
    if s["role"] == "hod":
        return {r["id"] for r in rows(c, "select id from modules where dept_id is not null and dept_id=?", s.get("dept_id"))} if s.get("dept_id") else set()
    return set()
def in_scope(sc, module_id): return sc is None or (module_id is not None and module_id in sc)

# ---------- sessions: the single source of truth ----------
def sessions(c, sc=None):
    out = []
    for e in rows(c, """select e.*, d.state dstate_raw, d.verified, d.minutes_late, d.actual_start, d.note dnote, d.report_id
                        from events e left join deliveries d on d.session_id=e.id where e.deleted=0 and e.module_id is not null and e.kind!='exam'"""):
        if not in_scope(sc, e["module_id"]): continue
        e["dstate"] = "cancelled" if e["status"] == "cancelled" else (e["dstate_raw"] if e["verified"] else None)   # only verified records count
        e["claimed"] = e["dstate_raw"] if (e["dstate_raw"] and not e["verified"]) else None
        e["past"] = bool(e["start"]) and comms.ev_end(e) <= comms.now()
        out.append(e)
    return out

# ---------- module status engine ----------
def module_facts(c, m, sess, cfg, idx_repl, reports, ints, comp):
    mine = [s for s in sess if s["module_id"] == m["id"]]
    sched = [s for s in mine if s["dstate"] != "cancelled"]
    ps = m.get("planned_start") or (min(s["date"] for s in sched) if sched else None)
    pe = m.get("planned_end") or (max(s["date"] for s in sched) if sched else None)
    commenced = sorted(s["date"] for s in mine if s["dstate"] in OK + ("incomplete",))
    missed = [s for s in mine if s["dstate"] in ("missed", "postponed")]
    unrepl = [s for s in missed if not any(r["dstate"] in OK for r in idx_repl.get(s["id"], []))]
    act_rep = [r for r in reports if r["status"] in ("pending", "clarification")]
    inv = [i for i in ints if i["state"] in INVESTIGATING]
    open_ints = [i for i in ints if i["state"] in OPEN]
    t = today()
    if act_rep or inv: st, why = "under_review", f"{len(act_rep)} report(s) awaiting review, {len(inv)} intervention(s) under investigation"
    elif comp: st, why = "completed", f"completion confirmed by {comp['by']}"
    elif not commenced: st, why = ("delayed", f"no verified teaching activity; planned commencement {ps} has passed") if ps and ps < t else ("not_commenced", "no verified teaching activity yet")
    elif len(unrepl) >= cfg["delay_missed"]: st, why = "delayed", f"{len(unrepl)} missed/postponed session(s) without a verified replacement"
    else: st, why = "in_progress", "verified teaching activity recorded; not formally completed"
    done = [s for s in sched if s["dstate"] in OK]
    return {"module_id": m["id"], "code": m["code"], "name": m["name"], "dept_id": m.get("dept_id"), "status": st, "reason": why, "evidence": ",".join([r["ref"] for r in act_rep] + [i["ref"] for i in inv]),
            "planned_start": ps, "actual_start": commenced[0] if commenced else None, "planned_end": pe, "actual_end": comp["ts"][:10] if comp and st == "completed" else None,
            "scheduled": len(sched), "delivered": len(done), "late": len([s for s in mine if s["dstate"] == "late"]), "missed": len(missed), "unreplaced_missed": len(unrepl),
            "outstanding": len(open_ints) + len(act_rep), "outstanding_sessions": [s["id"] for s in sched if s["dstate"] not in OK]}
def all_facts(c, sc=None):
    cfg, sess = comms.cfg(c), sessions(c, None)
    idx = {}
    for s in sess:
        if s.get("replaces_id"): idx.setdefault(s["replaces_id"], []).append(s)
    deps = {d["id"]: d["name"] for d in rows(c, "select * from departments")}
    out = []
    for m in rows(c, "select * from modules"):
        if not in_scope(sc, m["id"]): continue
        f = module_facts(c, m, sess, cfg, idx, rows(c, "select * from reports where module_id=?", m["id"]), rows(c, "select * from interventions where module_id=?", m["id"]), one(c, "select * from completions where module_id=?", m["id"]))
        f["department"] = deps.get(m["dept_id"], "Unassigned"); f["facilitators"] = [x["name"] for x in rows(c, "select name from facilitators where module_id=? and deleted=0", m["id"])]
        out.append(f)
    return out
def recompute(c, only=None, actor="system", kind="auto", reason=None, reviewer=None):
    n = 0
    for f in all_facts(c):
        if only and f["module_id"] != only: continue
        old = one(c, "select * from module_status where module_id=?", f["module_id"])
        if old and old["status"] == f["status"]: continue
        c.execute("insert into status_history(module_id,ts,old,new,actor,kind,reason,evidence,reviewer) values(?,?,?,?,?,?,?,?,?)",
                  (f["module_id"], ts(), old["status"] if old else None, f["status"], actor, kind, reason or f["reason"], f["evidence"], reviewer))
        c.execute("insert into module_status values(?,?,?) on conflict(module_id) do update set status=excluded.status,since=excluded.since", (f["module_id"], f["status"], ts())); n += 1
    return n
def mark_complete(c, s, module_id, reason, override=False):
    f = next((x for x in all_facts(c) if x["module_id"] == module_id), None)
    if not f: raise ValueError("Unknown module")
    if f["status"] == "under_review": raise ValueError("Module is under review; resolve the investigation before completion.")
    if not f["actual_start"]: raise ValueError("No verified teaching activity: the module cannot be completed.")
    if f["outstanding_sessions"] and not (override and s["role"] in ("admin", "dean") and reason.strip()):
        raise ValueError(f"{len(f['outstanding_sessions'])} scheduled session(s) lack a verified delivery record. Verify them first (admin/Dean may override with a written reason).")
    c.execute("insert into completions values(?,?,?,?) on conflict(module_id) do update set by=excluded.by,ts=excluded.ts,reason=excluded.reason", (module_id, s["name"], ts(), reason))
    recompute(c, module_id, s["name"], "authorised", reason or "Completion confirmed", s["name"]); comms.audit(c, s["name"], "module_complete", module_id)
def reopen_module(c, s, module_id, reason):
    if not reason.strip(): raise ValueError("A reason is required.")
    c.execute("delete from completions where module_id=?", (module_id,)); recompute(c, module_id, s["name"], "authorised", "Completion withdrawn: " + reason, s["name"]); comms.audit(c, s["name"], "module_reopen", module_id)
def module_history(c, mid): return rows(c, "select * from status_history where module_id=? order by id desc", mid)

# ---------- verified delivery ----------
def record_delivery(c, s, session_id, state, actual_start=None, actual_end=None, note="", report_id=None, sc=None):
    if state not in ("delivered", "late", "missed", "postponed", "incomplete"): raise ValueError("Invalid delivery state")
    e = one(c, "select * from events where id=? and deleted=0", session_id)
    if not e or not e["module_id"]: raise ValueError("Unknown session")
    if not in_scope(sc, e["module_id"]): raise PermissionError("Session is outside your department.")
    if state in ("delivered", "late", "incomplete") and not actual_start: actual_start = e["start"]
    late = 0
    if actual_start and e["start"] and state in ("delivered", "late"):
        a = dt.datetime.fromisoformat(f"{e['date']}T{actual_start}:00").replace(tzinfo=comms.TZ); late = max(0, int((a - comms.ev_start(e)).total_seconds() // 60))
        state = "late" if late > comms.cfg(c)["late_min"] else "delivered"
    old = one(c, "select state from deliveries where session_id=?", session_id)
    c.execute("insert into deliveries values(?,?,?,?,?,1,?,?,?,?,?,?) on conflict(session_id) do update set state=excluded.state,actual_start=excluded.actual_start,actual_end=excluded.actual_end,minutes_late=excluded.minutes_late,verified=1,recorded_by=excluded.recorded_by,verified_by=excluded.verified_by,ts=excluded.ts,source=excluded.source,note=excluded.note,report_id=excluded.report_id",
              (session_id, state, actual_start, actual_end, late, s["name"], s["name"], ts(), "report" if report_id else "coordinator", note, report_id))
    c.execute("insert into delivery_log(session_id,ts,actor,old_state,new_state,note) values(?,?,?,?,?,?)", (session_id, ts(), s["name"], old["state"] if old else None, state, note))
    comms.audit(c, s["name"], "delivery_" + state, session_id); recompute(c, e["module_id"], s["name"], "auto")
def verify_report(c, s, rid, outcome, note="", apply=True, sc=None):
    r = one(c, "select * from reports where id=?", rid)
    if not r: raise ValueError("Unknown report")
    if not in_scope(sc, r["module_id"]): raise PermissionError("Report is outside your department.")
    comms.set_report(c, rid, outcome, note, s["name"])
    if outcome == "verified" and apply and r["session_id"] and r["claimed_state"]: record_delivery(c, s, r["session_id"], r["claimed_state"], None, None, f"Verified from report {r['ref']}", rid, sc)
    recompute(c, r["module_id"], s["name"], "auto")

# ---------- notifications (in-app always; WhatsApp only through the consented comms queue) ----------
def gnotify(c, key, text, staff_rows=(), roles=()):
    if c.execute("insert or ignore into gov_notified values(?,?)", (key, ts())).rowcount == 0: return
    targets = list(staff_rows) + [x for r in roles for x in rows(c, "select * from staff where role=? and active=1", r)]
    for st in targets:
        c.execute("insert into inapp(person_id,ts,text,ref) values(?,?,?,?)", (None, ts(), text, f"staff:{st['id']}"))
        if st.get("person_id") and comms.has_consent(c, st["person_id"], "whatsapp_messages"): comms.queue(c, st["person_id"], text)   # routine updates never trigger voice calls
def staff_row(c, i): return one(c, "select * from staff where id=?", i) if i else None

# ---------- interventions ----------
def _log(c, iid, actor, a, b, note=""): c.execute("insert into intervention_log(intervention_id,ts,actor,from_state,to_state,note) values(?,?,?,?,?,?)", (iid, ts(), actor, a, b, note))
def create_intervention(c, s, d, sc=None):
    r = one(c, "select * from reports where id=?", d["report_id"]) if d.get("report_id") else None
    e = one(c, "select * from events where id=?", d.get("session_id") or (r and r["session_id"]) or 0)
    mid = d.get("module_id") or (r and r["module_id"]) or (e and e["module_id"])
    if not mid: raise ValueError("Choose a module, session or report.")
    if not in_scope(sc, mid): raise PermissionError("Module is outside your department.")
    m = one(c, "select * from modules where id=?", mid)
    ref = f"INT-{comms.now().year}-{c.execute('select count(*) from interventions').fetchone()[0] + 1:03d}"
    iid = c.execute("insert into interventions(ref,raised_ts,source,module_id,session_id,dept_id,facilitator_id,nature,description,report_id,severity,state,raised_by) values(?,?,?,?,?,?,?,?,?,?,?,'reported',?)",
        (ref, ts(), "class_rep_report" if r else d.get("source", "coordinator"), mid, e["id"] if e else None, m["dept_id"], d.get("facilitator_id") or (e and e["facilitator_id"]),
         d.get("nature") or (r and r["kind"]) or "other", d.get("description") or (r and r["body"]) or "", r["id"] if r else None, d.get("severity", "medium"), s["name"])).lastrowid
    _log(c, iid, s["name"], None, "reported", "Raised" + (f" from report {r['ref']}" if r else ""))
    if r: c.execute("update reports set intervention_id=? where id=?", (iid, r["id"]))
    if m["dept_id"]: gnotify(c, f"new:{iid}", f"New intervention {ref} for {m['code']}: {d.get('nature') or (r and r['kind'])}.", rows(c, "select * from staff where role='hod' and dept_id=? and active=1", m["dept_id"]))
    recompute(c, mid, s["name"], "auto"); comms.audit(c, s["name"], "intervention_create", ref); return iid
def _get(c, iid, sc):
    i = one(c, "select * from interventions where id=?", iid)
    if not i: raise ValueError("Unknown intervention")
    if i["module_id"] and not in_scope(sc, i["module_id"]): raise PermissionError("Intervention is outside your department.")
    return i
def transition(c, s, iid, to, note="", sc=None):
    i = _get(c, iid, sc)
    if to == "closed": raise ValueError("Use the verification step to close an intervention.")
    if to not in FLOW.get(i["state"], ()): raise ValueError(f"Cannot move from {i['state']} to {to}.")
    if s["role"] == "dean" and to not in ("escalated", "returned", "reopened"): raise PermissionError("The Executive Dean may escalate, return or reopen; operational steps belong to the Coordinator/HOD.")
    if to in ("resolved", "reopened", "returned", "escalated") and not note.strip(): raise ValueError("A note is required for this step.")
    _set(c, i, to, s["name"], note)
def _set(c, i, to, actor, note):
    c.execute("update interventions set state=?,resolved_ts=case when ?='resolved' then ? else resolved_ts end,closed_ts=case when ?='reopened' then NULL else closed_ts end where id=?", (to, to, ts(), to, i["id"]))
    _log(c, i["id"], actor, i["state"], to, note)
    if to == "resolved": gnotify(c, f"verify:{i['id']}:{ts()}", f"Intervention {i['ref']} is resolved and awaiting verification.", roles=("coordinator",))
    if to in ("reopened", "escalated"): gnotify(c, f"{to}:{i['id']}:{ts()}", f"Intervention {i['ref']} was {to}.", [x for x in (staff_row(c, i["responsible_staff_id"]),) if x], roles=("hod",) if to == "escalated" else ())
    recompute(c, i["module_id"], actor, "auto")
def assign(c, s, iid, staff_id, office, target_date, sc=None):
    i = _get(c, iid, sc); who = staff_row(c, staff_id)
    if not who and not (office or "").strip(): raise ValueError("Assign a responsible officer or office.")
    if not target_date: raise ValueError("Set a follow-up deadline.")
    dt.date.fromisoformat(target_date)
    note = f"Responsibility {'reassigned' if i['responsible_staff_id'] or i['responsible_office'] else 'assigned'} to {who['name'] if who else office}; follow-up by {target_date}"
    c.execute("update interventions set responsible_staff_id=?,responsible_office=?,target_date=? where id=?", (staff_id or None, office, target_date, iid)); _log(c, iid, s["name"], i["state"], i["state"], note)
    if i["state"] == "under_assessment": _set(c, {**i, "responsible_staff_id": staff_id}, "action_assigned", s["name"], note)
    if who: gnotify(c, f"assign:{iid}:{staff_id}:{target_date}", f"Intervention {i['ref']} assigned to you; follow-up by {target_date}.", [who])
def add_action(c, s, iid, category, note, due=None, sc=None):
    i = _get(c, iid, sc)
    if not one(c, "select 1 x from action_categories where name=? and active=1", category): raise ValueError("Unknown action category (administrators can add categories).")
    c.execute("insert into intervention_actions(intervention_id,ts,actor,category,note,due) values(?,?,?,?,?,?)", (iid, ts(), s["name"], category, note, due)); _log(c, iid, s["name"], i["state"], i["state"], f"Action: {category}. {note}")
    c.execute("update interventions set action_taken=? where id=?", (category, iid))
def complete_action(c, s, aid, outcome, sc=None):
    a = one(c, "select * from intervention_actions where id=?", aid); i = _get(c, a["intervention_id"], sc)
    if not outcome.strip(): raise ValueError("Record the outcome of the action.")
    c.execute("update intervention_actions set done=1,outcome=?,done_ts=? where id=?", (outcome, ts(), aid)); _log(c, i["id"], s["name"], i["state"], i["state"], f"Action completed: {a['category']} – {outcome}")
def link_replacement(c, s, iid, date, start, end, sc=None):
    i = _get(c, iid, sc); e = one(c, "select * from events where id=?", i["session_id"]) if i["session_id"] else None
    if not e: raise ValueError("This intervention is not linked to a session.")
    if not (date and start and end and start < end): raise ValueError("Enter date and valid start/end times.")
    rid = c.execute("insert into events(title,module_id,facilitator_id,venue,description,date,start,end,kind,status,stype,mode,replaces_id) values(?,?,?,?,?,?,?,?,?,'scheduled',?,?,?)",
        ("Replacement: " + e["title"], e["module_id"], e["facilitator_id"], e["venue"], f"Replacement for session {e['id']} ({i['ref']})", date, start, end, "session", e["stype"], e["mode"], e["id"])).lastrowid
    c.execute("update interventions set replacement_session_id=? where id=?", (rid, iid)); _log(c, iid, s["name"], i["state"], i["state"], f"Replacement session #{rid} proposed for {date} {start}–{end} (NOT yet delivered)"); return rid
def close(c, s, iid, note, waive=False, sc=None):
    i = _get(c, iid, sc)
    if i["state"] != "resolved": raise ValueError("Only a resolved intervention can be verified and closed.")
    if not note.strip(): raise ValueError("Verification note required.")
    sess = one(c, "select e.id, d.state, d.verified from events e left join deliveries d on d.session_id=e.id where e.id=?", i["session_id"]) if i["session_id"] else None
    if sess and sess["verified"] and sess["state"] in ("missed", "postponed", "incomplete"):
        rep = one(c, "select e.id, d.state, d.verified from events e left join deliveries d on d.session_id=e.id where e.id=?", i["replacement_session_id"]) if i["replacement_session_id"] else None
        delivered = bool(rep and rep["verified"] and rep["state"] in OK)
        if not delivered:
            if not (waive and s["role"] in ("hod", "dean", "admin")): raise ValueError("The replacement session has not been independently verified as delivered. (HOD/Dean/admin may waive with a written reason.)")
            note = "WAIVED: " + note
    c.execute("update interventions set state='closed',closed_ts=?,confirmed_by=? where id=?", (ts(), s["name"], iid)); _log(c, iid, s["name"], "resolved", "closed", note)
    comms.audit(c, s["name"], "intervention_close", i["ref"]); recompute(c, i["module_id"], s["name"], "auto")
def detail(c, iid, sc=None):
    i = _get(c, iid, sc)
    return {**i, "actions": rows(c, "select * from intervention_actions where intervention_id=? order by id", iid), "log": rows(c, "select * from intervention_log where intervention_id=? order by id", iid),
            "report": one(c, "select * from reports where id=?", i["report_id"]) if i["report_id"] else None,
            "replacement": one(c, "select e.*, d.state dstate, d.verified from events e left join deliveries d on d.session_id=e.id where e.id=?", i["replacement_session_id"]) if i["replacement_session_id"] else None}
def is_overdue(i): return bool(i["target_date"] and i["state"] in OPEN and i["target_date"] < today())
def list_interventions(c, sc=None, **f):
    out = []
    for i in rows(c, "select i.*, m.code module, d.name department, s.name responsible from interventions i left join modules m on m.id=i.module_id left join departments d on d.id=i.dept_id left join staff s on s.id=i.responsible_staff_id order by i.id desc"):
        if i["module_id"] and not in_scope(sc, i["module_id"]): continue
        i["overdue"] = is_overdue(i)
        if f.get("status") and i["state"] != f["status"]: continue
        if f.get("module_id") and i["module_id"] != int(f["module_id"]): continue
        if f.get("dept_id") and i["dept_id"] != int(f["dept_id"]): continue
        if f.get("severity") and i["severity"] != f["severity"]: continue
        if f.get("facilitator_id") and i["facilitator_id"] != int(f["facilitator_id"]): continue
        if f.get("responsible_id") and i["responsible_staff_id"] != int(f["responsible_id"]): continue
        if f.get("date_from") and i["raised_ts"][:10] < f["date_from"]: continue
        if f.get("date_to") and i["raised_ts"][:10] > f["date_to"]: continue
        if f.get("overdue") and not i["overdue"]: continue
        out.append(i)
    return out

def tick(c):
    """Follow-up reminders, overdue escalation and status refresh. Called by the server worker."""
    cf = comms.cfg(c); t = dt.date.fromisoformat(today()); n = 0
    for i in rows(c, f"select * from interventions where state in ({','.join('?' * len(OPEN))})", *OPEN):
        if not i["target_date"]: continue
        td = dt.date.fromisoformat(i["target_date"]); who = [x for x in (staff_row(c, i["responsible_staff_id"]),) if x]
        if 0 <= (td - t).days <= cf["followup_warn_days"] and i["state"] in ("action_assigned", "follow_up"): gnotify(c, f"warn:{i['id']}:{i['target_date']}", f"Follow-up for {i['ref']} is due on {i['target_date']}.", who); n += 1
        if td < t:
            gnotify(c, f"over:{i['id']}:{i['target_date']}", f"Intervention {i['ref']} is OVERDUE (target {i['target_date']}).", who, roles=("coordinator",)); n += 1
            if (t - td).days >= cf["overdue_esc_days"] and "escalated" in FLOW.get(i["state"], ()): _set(c, i, "escalated", "system", f"Auto-escalated: overdue by {(t - td).days} days"); n += 1
    return n + recompute(c)

# ---------- dashboards ----------
def _period(sess, f):
    return [s for s in sess if (not f.get("date_from") or s["date"] >= f["date_from"]) and (not f.get("date_to") or s["date"] <= f["date_to"])]
def _agg(sess):
    due = [s for s in sess if s["past"] and s["dstate"] != "cancelled"]
    d = {"planned_to_date": len(due), "delivered": sum(s["dstate"] in OK for s in due), "late": sum(s["dstate"] == "late" for s in due), "missed": sum(s["dstate"] == "missed" for s in due),
         "postponed": sum(s["dstate"] == "postponed" for s in due), "incomplete": sum(s["dstate"] == "incomplete" for s in due), "cancelled": sum(s["dstate"] == "cancelled" for s in sess),
         "awaiting_verification": sum(s["dstate"] is None for s in due), "total_planned": len([s for s in sess if s["dstate"] != "cancelled"])}
    d["rate"] = round(d["delivered"] / d["planned_to_date"], 3) if d["planned_to_date"] else None
    return d
def _iagg(ints):
    closed = [i for i in ints if i["state"] == "closed"]; rt = [(dt.datetime.fromisoformat(i["closed_ts"]) - dt.datetime.fromisoformat(i["raised_ts"])).total_seconds() / 86400 for i in closed]
    return {"raised": len(ints), "open": sum(i["state"] in OPEN for i in ints), "resolved": sum(i["state"] in ("resolved", "closed") for i in ints), "closed": len(closed), "overdue": sum(is_overdue(i) for i in ints),
            "escalated": sum(i["state"] == "escalated" for i in ints), "awaiting_verification": sum(i["state"] == "resolved" for i in ints), "avg_resolution_days": round(sum(rt) / len(rt), 1) if rt else None}
def overview(c, sc=None, **f):
    sess = _period(sessions(c, sc), f); facts = all_facts(c, sc); ints = list_interventions(c, sc, date_from=f.get("date_from"), date_to=f.get("date_to"))
    status = {k: sum(x["status"] == k for x in facts) for k in STATUSES}; modes = {}
    for s in sess:
        if s["dstate"] != "cancelled": modes[s["mode"] or "not_recorded"] = modes.get(s["mode"] or "not_recorded", 0) + 1
    deps = []
    for did, name in [(r["id"], r["name"]) for r in rows(c, "select * from departments")] + [(None, "Unassigned")]:
        mf = [x for x in facts if x["dept_id"] == did]
        if not mf: continue
        ids = {x["module_id"] for x in mf}; ds = [s for s in sess if s["module_id"] in ids]; di = [i for i in ints if i["module_id"] in ids]
        deps.append({"dept_id": did, "name": name, "modules": len(mf), "status": {k: sum(x["status"] == k for x in mf) for k in STATUSES}, **_agg(ds), "interventions": _iagg(di)})
    weeks = {}
    for s in sess:
        if s["past"]:
            wk = (dt.date.fromisoformat(s["date"]) - dt.timedelta(days=dt.date.fromisoformat(s["date"]).weekday())).isoformat(); weeks.setdefault(wk, []).append(s)
    return {"programme": {"modules": len(facts), "status": status, **_agg(sess)}, "modes": modes, "interventions": _iagg(ints), "departments": deps,
            "trend": [{"week": k, **{x: v for x, v in _agg(vs).items() if x in ("planned_to_date", "delivered", "late", "missed", "postponed", "incomplete")}} for k, vs in sorted(weeks.items())],
            "unassigned_note": "Assign modules to departments (Governance → Departments) to enable departmental comparison." if any(d["dept_id"] is None for d in deps) else None}
def ops(c, sc=None):
    sess = sessions(c, sc); t = today(); wk = (dt.date.fromisoformat(t) + dt.timedelta(days=7)).isoformat()
    fac = {x["id"]: x["name"] for x in rows(c, "select id,name from facilitators")}; mods = {m["id"]: m["code"] for m in rows(c, "select id,code from modules")}
    slim = lambda s: {"id": s["id"], "title": s["title"], "module": mods.get(s["module_id"]), "module_id": s["module_id"], "date": s["date"], "start": s["start"], "end": s["end"], "facilitator": fac.get(s["facilitator_id"]), "state": s["dstate"], "claimed": s["claimed"], "minutes_late": s["minutes_late"]}
    facts = all_facts(c, sc); ints = list_interventions(c, sc); reps = [r for r in rows(c, "select r.*, m.code module from reports r left join modules m on m.id=r.module_id order by r.id desc") if in_scope(sc, r["module_id"]) or r["module_id"] is None and sc is None]
    return {"today": [slim(s) for s in sess if s["date"] == t], "upcoming": [slim(s) for s in sess if t < s["date"] <= wk and s["dstate"] != "cancelled"],
            "late": [slim(s) for s in sess if s["dstate"] == "late"], "missed": [slim(s) for s in sess if s["dstate"] == "missed"], "postponed_cancelled": [slim(s) for s in sess if s["dstate"] in ("postponed", "cancelled")],
            "incomplete": [slim(s) for s in sess if s["dstate"] == "incomplete"], "awaiting_verification": [slim(s) for s in sess if s["past"] and s["dstate"] is None][:100],
            "modules_attention": [x for x in facts if x["status"] in ("not_commenced", "delayed", "under_review")], "reports_pending": [r for r in reps if r["status"] == "pending"], "reports_clarification": [r for r in reps if r["status"] == "clarification"],
            "interventions": [i for i in ints if i["state"] in OPEN or i["state"] == "resolved"], "overdue": [i for i in ints if i["overdue"]],
            "actions_due": rows(c, "select a.*, i.ref from intervention_actions a join interventions i on i.id=a.intervention_id where a.done=0 and a.due is not null and a.due<=? order by a.due", wk),
            "alarms": rows(c, "select r.kind, r.offset_min, r.due, r.event_id from reminders r where r.status='pending' order by r.due limit 15")}
def drill(c, sc=None, dept=None, module=None, session=None, intervention=None):
    if intervention: d = detail(c, int(intervention), sc); return {"level": "intervention", "data": d}
    if session:
        e = one(c, "select * from events where id=?", int(session))
        if not e or not in_scope(sc, e["module_id"]): raise PermissionError("Session is outside your scope.")
        return {"level": "session", "data": {"session": e, "delivery": one(c, "select * from deliveries where session_id=?", e["id"]), "delivery_log": rows(c, "select * from delivery_log where session_id=? order by id", e["id"]),
            "reports": rows(c, "select * from reports where session_id=?", e["id"]), "interventions": rows(c, "select * from interventions where session_id=?", e["id"]), "replacements": rows(c, "select e.*, d.state dstate, d.verified from events e left join deliveries d on d.session_id=e.id where e.replaces_id=?", e["id"])}}
    if module:
        f = next((x for x in all_facts(c, sc) if x["module_id"] == int(module)), None)
        if not f: raise PermissionError("Module is outside your scope.")
        return {"level": "module", "data": {"module": f, "history": module_history(c, f["module_id"]), "sessions": [s for s in sessions(c, sc) if s["module_id"] == f["module_id"]], "reports": rows(c, "select * from reports where module_id=?", f["module_id"]), "interventions": list_interventions(c, sc, module_id=f["module_id"])}}
    if dept is not None:
        did = None if dept in ("none", "") else int(dept); return {"level": "department", "data": {"modules": [x for x in all_facts(c, sc) if x["dept_id"] == did], "interventions": [i for i in list_interventions(c, sc) if i["dept_id"] == did]}}
    return {"level": "programme", "data": overview(c, sc)}
def export_csv(c, sc, what):
    buf = io.StringIO(); w = csv.writer(buf)
    if what == "interventions":
        w.writerow(["ref", "raised", "module", "department", "nature", "severity", "state", "responsible", "target_date", "overdue", "resolved", "closed", "confirmed_by"])
        for i in list_interventions(c, sc): w.writerow([i["ref"], i["raised_ts"][:10], i["module"], i["department"], i["nature"], i["severity"], i["state"], i["responsible"] or i["responsible_office"], i["target_date"], i["overdue"], (i["resolved_ts"] or "")[:10], (i["closed_ts"] or "")[:10], i["confirmed_by"]])
    else:
        w.writerow(["code", "name", "department", "status", "reason", "planned_start", "actual_start", "planned_end", "actual_end", "scheduled", "delivered", "missed", "outstanding"])
        for f in all_facts(c, sc): w.writerow([f["code"], f["name"], f["department"], f["status"], f["reason"], f["planned_start"], f["actual_start"], f["planned_end"], f["actual_end"], f["scheduled"], f["delivered"], f["missed"], f["outstanding"]])
    return buf.getvalue()

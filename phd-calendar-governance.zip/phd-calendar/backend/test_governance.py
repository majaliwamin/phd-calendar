"""Offline tests for governance: status engine, delivery verification, interventions, scope, immutability."""
import os, sys, tempfile, sqlite3, datetime as dt
os.environ["CAL_DATA"] = tempfile.mkdtemp()
import db, comms, governance as g
db.init()
with db.conn() as c: comms.init(c); g.init(c)
T = comms.TZ; BASE = dt.datetime(2026, 11, 16, 12, 0, tzinfo=T); comms.CLOCK = lambda: BASE
C = db.conn(); ok = bad = 0
def chk(n, cond):
    global ok, bad; ok += bool(cond); bad += (not cond); print("PASS" if cond else "FAIL", n)
def raises(fn, exc=Exception):
    try: fn(); return False
    except exc: return True
adm = {"name": "Admin", "role": "admin", "dept_id": None, "id": 1}; co = {"name": "Coord", "role": "coordinator", "dept_id": None, "id": 2}
dean = {"name": "Dean", "role": "dean", "dept_id": None, "id": 3}
C.execute("insert into departments(name) values('Maternal Health'),('Neonatal Health')"); C.commit()
C.execute("update modules set dept_id=1 where id in (1,2)"); C.execute("update modules set dept_id=2 where id in (3,4)")
for nm, rl, dp in (("Admin", "admin", None), ("Coord", "coordinator", None), ("Dean", "dean", None), ("HOD1", "hod", 1)): comms.new_staff(C, nm, rl, None, dp)
C.commit()
hod = {"name": "HOD1", "role": "hod", "dept_id": 1, "id": 4}
def ev(mod, date, st, en, title="Session", fac=None, mode=None):
    return C.execute("insert into events(title,module_id,facilitator_id,date,start,end,kind,mode) values(?,?,?,?,?,?,'session',?)", (title, mod, fac, date, st, en, mode)).lastrowid
past1 = ev(1, "2026-11-09", "09:00", "11:00", "MPN intro", mode="face_to_face"); past2 = ev(1, "2026-11-10", "09:00", "11:00", "MPN 2", mode="online")
m2s = ev(2, "2026-11-30", "09:00", "10:00", "ARMN future"); m3s = ev(3, "2026-11-10", "13:00", "15:00", "PMN overdue start"); C.commit()
st = lambda mid: next(x for x in g.all_facts(C) if x["module_id"] == mid)["status"]
g.recompute(C); C.commit()
chk("no verified activity + commencement date passed => Delayed (not In progress)", st(3) == "delayed")
chk("future module with no activity => Not commenced", st(2) == "not_commenced")
chk("module with sessions in the past but no record is NOT In progress", st(1) == "delayed")
g.record_delivery(C, co, past1, "delivered", "09:00", "11:00"); C.commit()
chk("verified delivery => In progress", st(1) == "in_progress")
# class-rep report => under review
pid = comms.save_person(C, {"name": "CR One", "role": "class_rep", "phone": "0991112222", "module_id": 1}); comms.set_consent(C, pid, "whatsapp_messages", "granted", "t")
ref = comms.new_report(C, pid, 1, "missed session", "Session did not hold", past2); C.commit(); g.recompute(C); C.commit()
chk("pending report => Under review (precedence over In progress)", st(1) == "under_review")
chk("a submitted report is NOT a verified fact (session stays unverified)", [s for s in g.sessions(C) if s["id"] == past2][0]["dstate"] is None and C.execute("select count(*) from deliveries where session_id=?", (past2,)).fetchone()[0] == 0)
rid = C.execute("select id from reports").fetchone()[0]
iid = g.create_intervention(C, co, {"report_id": rid}); C.commit(); I = lambda: comms.one(C, "select * from interventions where id=?", iid)
chk("intervention created from report without re-entry", I()["module_id"] == 1 and I()["session_id"] == past2 and I()["description"] == "Session did not hold" and I()["nature"] == "missed session" and I()["ref"] == "INT-2026-001")
chk("intervention linked back to report", comms.one(C, "select intervention_id i from reports where id=?", rid)["i"] == iid)
chk("module Under review while investigated", st(1) == "under_review")
g.verify_report(C, co, rid, "verified", "confirmed with facilitator", True); C.commit()
chk("verified report records the missed session as a verified fact", [s for s in g.sessions(C) if s["id"] == past2][0]["dstate"] == "missed")
for to, note in (("acknowledged", ""), ("under_assessment", "")): g.transition(C, co, iid, to, note)
chk("invalid jump rejected", raises(lambda: g.transition(C, co, iid, "resolved", "x"), ValueError))
g.assign(C, co, iid, 4, "", "2026-11-17"); C.commit()
chk("assignment sets responsible + deadline and moves to Action assigned", I()["responsible_staff_id"] == 4 and I()["target_date"] == "2026-11-17" and I()["state"] == "action_assigned")
chk("assigned officer notified in-app", C.execute("select count(*) from inapp where ref='staff:4'").fetchone()[0] >= 1)
g.add_action(C, co, iid, "Contacted the facilitator", "Phoned Dr X", "2026-11-16"); aid = C.execute("select id from intervention_actions").fetchone()[0]
chk("unknown action category rejected (configurable list)", raises(lambda: g.add_action(C, co, iid, "Made up", "x"), ValueError))
g.complete_action(C, co, aid, "Facilitator confirmed illness"); g.transition(C, co, iid, "follow_up", ""); C.commit()
BASE += dt.timedelta(days=2); g.tick(C); C.commit()
chk("overdue intervention identified", any(i["overdue"] for i in g.list_interventions(C)))
chk("overdue notice sent once to officer/coordinator", C.execute("select count(*) from inapp where text like '%OVERDUE%'").fetchone()[0] >= 1)
n = C.execute("select count(*) from inapp").fetchone()[0]; g.tick(C); chk("no duplicate overdue notices", C.execute("select count(*) from inapp").fetchone()[0] == n)
BASE += dt.timedelta(days=2); g.tick(C); C.commit()
chk("long-overdue intervention auto-escalated (system)", I()["state"] == "escalated")
# reassignment audit
g.transition(C, co, iid, "follow_up", ""); g.assign(C, co, iid, 2, "", "2026-12-01"); C.commit()
chk("reassignment recorded in audit log", C.execute("select count(*) from intervention_log where note like 'Responsibility reassigned%'").fetchone()[0] == 1)
# replacement does not close / count
rep = g.link_replacement(C, co, iid, "2026-11-20", "09:00", "11:00"); C.commit()
g.transition(C, co, iid, "resolved", "Replacement scheduled"); C.commit()
chk("rescheduling does not close the original intervention", I()["state"] == "resolved" and I()["closed_ts"] is None)
chk("original missed-session report preserved", comms.one(C, "select status from reports where id=?", rid)["status"] == "verified")
chk("proposed replacement not counted as delivered", [s for s in g.sessions(C) if s["id"] == rep][0]["dstate"] is None)
chk("cannot close until replacement independently verified", raises(lambda: g.close(C, co, iid, "ok"), ValueError))
chk("coordinator cannot waive", raises(lambda: g.close(C, co, iid, "ok", True), ValueError))
BASE = dt.datetime(2026, 11, 20, 12, 0, tzinfo=T)
g.record_delivery(C, co, rep, "delivered", "09:00", "11:00", "Replacement held"); C.commit()
g.close(C, co, iid, "Replacement verified delivered"); C.commit()
chk("close succeeds only after verified replacement delivery", I()["state"] == "closed" and I()["confirmed_by"] == "Coord")
chk("closed interventions stay in historical reporting", any(i["id"] == iid for i in g.list_interventions(C)) and g.overview(C)["interventions"]["closed"] == 1)
chk("late arrival computed from actual start", (lambda: (g.record_delivery(C, co, past2, "delivered", "09:40", "11:00"), [s for s in g.sessions(C) if s["id"] == past2][0]["dstate"])[1])() == "late")
# completion rules
chk("module cannot complete while sessions lack verified delivery or under review", raises(lambda: g.mark_complete(C, co, 2, "x"), ValueError))
BASE = dt.datetime(2026, 12, 30, 12, 0, tzinfo=T); g.recompute(C)
chk("scheduled end date passing does NOT complete a module", st(2) != "completed")
chk("Executive Dean cannot record deliveries (no perm in API; engine needs authorised role)", comms.can("dean", "gov_record") is False)
g.record_delivery(C, co, m2s, "delivered"); C.commit(); g.mark_complete(C, co, 2, "All sessions verified"); C.commit()
chk("authorised completion => Completed", st(2) == "completed")
h = comms.rows(C, "select * from status_history where module_id=2 order by id")
chk("every status change has history incl. actor/kind/reason", len(h) >= 2 and all(r["actor"] and r["kind"] and r["reason"] for r in h) and h[-1]["kind"] == "authorised" and h[-1]["reviewer"] == "Coord" and h[0]["kind"] == "auto")
# immutability
for t, sql in (("status_history", "update status_history set actor='x'"), ("intervention_log", "delete from intervention_log"), ("delivery_log", "update delivery_log set note='x'")):
    chk(f"{t} is immutable", raises(lambda: C.execute(sql), sqlite3.DatabaseError))
# scope / departments / executive
sc = g.scope(C, hod)
chk("HOD sees only own department modules", sc == {1, 2} and all(x["module_id"] in sc for x in g.all_facts(C, sc)))
chk("HOD cannot open out-of-department module/intervention", raises(lambda: g.drill(C, sc, module=3), PermissionError))
chk("HOD without department sees nothing", g.scope(C, {"role": "hod", "dept_id": None, "name": "h"}) == set() and g.all_facts(C, set()) == [])
chk("student/class_rep have no governance scope", g.scope(C, {"role": "class_rep", "name": "x"}) == set())
ov = g.overview(C)
chk("executive overview is consolidated (no session lists)", "sessions" not in ov and "departments" in ov and "programme" in ov)
chk("departmental comparison with intervention stats", {d["name"] for d in ov["departments"]} >= {"Maternal Health", "Neonatal Health"} and all("interventions" in d for d in ov["departments"]))
chk("planned vs delivered + modes reported", ov["programme"]["delivered"] >= 1 and ov["modes"].get("face_to_face") == 1 and ov["modes"].get("not_recorded", 0) >= 1)
chk("trend by week available", len(ov["trend"]) >= 1 and "missed" in ov["trend"][0])
chk("drill-down hierarchy works", all(g.drill(C, None, **k)["level"] == l for k, l in ((dict(), "programme"), (dict(dept="1"), "department"), (dict(module=1), "module"), (dict(session=past2), "session"), (dict(intervention=iid), "intervention"))))
chk("dashboards share records: ops + overview agree on modules", len(g.all_facts(C)) == ov["programme"]["modules"])
chk("dean limited to escalate/return/reopen", raises(lambda: g.transition(C, dean, iid, "reopened", "") or g.transition(C, dean, iid, "under_assessment", "x"), (PermissionError, ValueError)))
chk("ops dashboard lists actionable items", all(k in g.ops(C) for k in ("late", "missed", "reports_pending", "overdue", "interventions", "awaiting_verification", "actions_due", "modules_attention")))
chk("csv export works", g.export_csv(C, None, "interventions").startswith("ref,") and g.export_csv(C, None, "modules").startswith("code,"))
chk("routine notices never trigger voice calls (queue is message-only)", C.execute("select count(*) from reminders where kind='call' and note like '%ntervention%'").fetchone()[0] == 0)
# restore path: audit tables are replaced only with triggers suspended, then protected again
C.commit(); C.execute("begin immediate"); g.suspend_triggers(C); C.execute("delete from status_history"); g.triggers(C); C.commit()
chk("restore can replace audit tables and immutability is re-armed", C.execute("select count(*) from status_history").fetchone()[0] == 0 and raises(lambda: C.execute("insert into status_history(module_id) values(1)") and C.execute("update status_history set actor='x'"), sqlite3.DatabaseError))
print(f"\n{ok} passed, {bad} failed"); sys.exit(1 if bad else 0)
